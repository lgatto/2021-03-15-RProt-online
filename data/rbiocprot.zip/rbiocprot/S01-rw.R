library("msdata")
f <- proteomics(full.names = TRUE)
basename(f)
f2 <- f[4]
f2
basename(f2)

library(mzR)

openMSfile("~/wrk/2020-02-17-RProt-Berlin/TMT_Erwinia_1uLSike_Top10HCD_isol2_45stepped_60min_01-20141210.mzML")

ms <- openMSfile(f2)
ms

hd <- header(ms)
class(hd)
View(hd)

names(hd)

## how many spectra? - tip: length
nrow(hd)
length(ms)
## how many MS1 spectra?
## how many MS2 spectra?
table(hd$msLevel)

head(peaks(ms, 100))
hd[100, ]

str(peaks(ms, 1000:1005))
hd$msLevel[1000:1005]

## Let’s extract the index of the 
## MS2 spectrum with the highest 
## base peak intensity and plot its 
## spectrum. 

hd2 <- hd[hd$msLevel == 2, ]
hd2[which.max(hd2$basePeakIntensity), ]
i <- 5404
pi <- peaks(ms, i)
plot(pi, type = "h")

## Is the data centroided or in 
## profile mode?

plot(pi, type = "h", xlim = c(859, 860))

library("MSnbase")

rw1 <- readMSData(f2, mode = "onDisk")
rw2 <- readMSData(f2, mode = "inMemory")
rw1
rw2

## feature metadata ~ header
fData(rw1) 

rw1[[5404]]
rw1[[300]]

plot(rw1[[5404]])
plot(rw1[[300]])

plot(rw2[[300]])

rw1[[300]]
rw2[[300]]

length(rw1)
length(rw2)

rtime(rw1)
table(msLevel(rw1))
table(centroided(rw1))

## Are MS1 and/or MS2 
## spectra centroided?

table(msLevel(rw1),
      centroided(rw1))


## Using the file starting with 
## MS3TMT10:

f[3]

## - Create an MSnExp object
rw3 <- readMSData(f[3], mode = "onDisk")
rw3
## - What MS levels do you have, 
##   and how many spectra of each
table(msLevel(rw3))

## - What is the mode of the 
##   different MS levels
table(msLevel(rw3),
      centroided(rw3))

## reproduce figure
rw1
## part 1
chr1 <- chromatogram(rw1)
chr1
rw1[[1]]
fileNames(rw1)

# library(msdata)
# f <- c(system.file("microtofq/MM14.mzML", package = "msdata"),
#        system.file("microtofq/MM8.mzML", package = "msdata"))
# msd <- readMSData(f, msLevel = 1)
# basename(fileNames(msd))
# tic <- chromatogram(msd)
# tic 
# tic[1, 1]
# tic[1, 2]

plot(tic[1, 1], col = "black")
plot(tic[1, 2], col = "black")

sel_rt <- rtime(rw1) > 30 * 60
sel_ms1 <- msLevel(rw1) == 1
sel <- which(sel_rt & sel_ms1)
i1 <- sel[1]
i2 <- sel[2]

plot(chr1, col = "black")
abline(v = rtime(rw1)[i1], 
       col = "red")

## part 2
p <- plot(rw1[[i1]])
p + ggplot2::xlim(400, 800)

spdf <- as(rw1[[i1]], "data.frame")
head(spdf)

plot(spdf, type = "h", 
     xlim = c(400, 1000))
precursorMz(rw1)

fvarLabels(rw1)
which(fData(rw1)$precursorScanNum == i1)
# i1
# i2
# (i1+1):(i1+10)
k <- which(fData(rw1)$precursorScanNum == i1)
precursorMz(rw1)[k]
prec_mz <- precursorMz(rw1)[k]

  plot(spdf, type = "h", 
       xlim = c(400, 1000))
  abline(v = prec_mz, 
         col = c("red",
                 rep("grey", 9)))

plot(spdf, type = "h", 
       xlim = c(400, 1000))
abline(v = prec_mz)

table(centroided(rw1),
      msLevel(rw1))

prec_mz[1]
plot(spdf, type = "l", 
     xlim = c(prec_mz[1] - 0.5,
              prec_mz[1] + 1))
abline(v = prec_mz[1], 
       col = "red")

as(rw1[[i1]], "data.frame")
as.data.frame(rw1[[i1]])

rw1[k]
plot(rw1[[2810]], full = TRUE)
plot(rw1[[2810]], 
     reporters = TMT6)
plot(rw1[[2810]], 
     reporters = TMT6, 
     full = TRUE)


plot(rw1[k[2:3]], full = TRUE)
plot(rw1[k[1:2]], full = TRUE)
plot(rw1[k], full = TRUE)

p1 <- plot(rw1[k[1]], full = TRUE)
p2 <- plot(rw1[k[2]], full = TRUE)


par(mfrow = c(2, 5))
for (i in k)
  plot(as.data.frame(rw1[[i]]), 
       type = "h")

i1
rw4 <- filterPrecursorScan(rw1, 
                           i1)
plot(rw4[[1]])
plot(rw4[[2]])

library(magrittr)
rw3
i <- acquisitionNum(rw3)[1]
filterPrecursorScan(rw3, i) %>%
  msLevel() %>%
  table

data(itraqdata)
itraqdata

## plot m/z region 915 to 925 
## of 10th spectrum
library(ggplot2)
p_prof <- 
  plot(itraqdata[[10]]) + 
  xlim(915, 925)

plot(as(itraqdata[[10]], "data.frame"),
     type = "h", 
     xlim = c(916, 920))

plot(as(pickPeaks(itraqdata[[10]]), "data.frame"),
     type = "h", 
     xlim = c(916, 920))

plot(as(pickPeaks(itraqdata[[10]]), "data.frame"),
     type = "h")

## pick peaks of itraqdata using
## pickPeaks() and plot as above

sp <- itraqdata[[10]]
p_prof <- plot(sp) + xlim(915, 925)

sp2 <- pickPeaks(sp)
sp2
p_cent <- plot(sp2) + xlim(915, 925)

BiocManager::install("thomasp85/patchwork")
library(patchwork)
p_prof + p_cent

it2 <- pickPeaks(itraqdata)
plot(it2[[10]]) + xlim(915, 925)

plot(it2[[14]])
s <- as.character(fData(it2)$PeptideSequence[14])
calculateFragments(s)
