library(MSnbase)

data("itraqdata")
plot(itraqdata[[25]], 
     full = TRUE, 
     reporters = iTRAQ4)


data(msnset)
dim(msnset)
## expression data
exprs(msnset)[1:10, 1:2]
sampleNames(msnset)
featureNames(msnset)

## feature meta-data
class(fData(msnset))
dim(fData(msnset))
fvarLabels(msnset)

## sample meta-data
pData(msnset)
msnset$group <- c("A", "A",
                  "B", "B")
pData(msnset)

## Creating MSnSet from raw data
## (see ?quantify)

## Creating MSnSet from 
## third-party software

BiocManager::install("pRolocdata")
csvfile <- 
  dir(system.file("extdata", 
            package = "pRolocdata"),
    pattern = "ms3-rep12", 
    full.names = TRUE)
basename(csvfile)

## View(read.csv(csvfile)[1:100, ])
getEcols(csvfile, split = ",", n = 2)

msn <- 
  readMSnSet2(csvfile, 
              ecol = 8:27,
              fnames = 1,
              skip = 1)
msn
sampleNames(msn)
head(featureNames(msn))
fvarLabels(msn)
fData(msn)

pData(msn)
dim(msn)
pData(msn)$batch <- 
  rep(1:2, each = 10)
pData(msn)$group <- 
  rep(rep(c("CTRL", "COND"), 
            each = 5),
          2)
pData(msn)

featureNames(msn)


f <- msdata::quant(full.names = TRUE)
f

getEcols(f, split = "\t")

i <- grepEcols(f, 
          "Intensity ",
          split = "\t")

cptac <- 
  readMSnSet2(f, ecol = i,
              sep = "\t")
cptac
fvarLabels(cptac)

featureNames(cptac) <- 
  fData(cptac)$Sequence
cptac

sampleNames(cptac) <- 
  sub("Intensity\\.",
      "",
      sampleNames(cptac))
sampleNames(cptac)

cptac$condition <- 
  rep(c("A", "B"),
      each = 3)
pData(cptac)$sample <- 
  rep(7:9, 2)
pData(cptac)

sub("_.+", "", 
    sampleNames(cptac))

sub("^.+_", "", 
    sampleNames(cptac))

cptac <- 
  selectFeatureData(cptac,
                  fcol = c(
                    "Proteins",
                    "Potential.contaminant",
                    "Reverse",
                    "Sequence"))

fvarLabels(cptac)
cptac

head(grep(";", fData(cptac)$Proteins,
      value = TRUE))

View(fData(cptac)[1:10, ])

table(fData(cptac)$Reverse)
table(fData(cptac)$Potential.contaminant)

## BiocManager::install("statOmics/MSqRob")

keep <- MSqRob::smallestUniqueGroups(
            fData(cptac)$Proteins)

head(keep)

## what does this do?
prots <- c("X", "Z", "A;B", "A;B;C")
MSqRob::smallestUniqueGroups(prots)

## how to subset cptac to keep 
## those protein(group)s?

cptac <- 
  cptac[fData(cptac)$Protein %in% keep
, ]

dim(cptac)
dim(cptac[, cptac$condition == "A"])
pData(cptac)

## subsetting samples (example)

fvarLabels(cptac)
fvarLabels(cptac[, cptac$condition == "A"])

## filter contaminants and reverse 
## hits out.

sel1 <- fData(cptac)$Potential.contaminant != "+"
sel2 <- fData(cptac)$Reverse != "+"
table(sel1)
table(sel2)
cptac <- cptac[sel1 & sel2, ]

ptm_only <- c("REV__CON__Q3T052", "REV__sp|P01120|RAS2_YEAST",
              "REV__sp|P32849|RAD5_YEAST",
              "REV__sp|Q03723|OST6_YEAST", "sp|P04051|RPC1_YEAST",
              "sp|P06367|RS14A_YEAST",
              "sp|P0CX73|YP11A_YEAST;sp|P0CX72|YL12A_YEAST;sp|P0CX71|YE11A_YEAST;sp|P0CX70|YD15A_YEAST;sp|Q6Q5H1|YP14A_YEAST;sp|P0C2I8|YL14A_YEAST",
              "sp|P19657|PMA2_YEAST", "sp|P32465|HXT1_YEAST",
              "sp|P39567|IMDH1_YEAST", "sp|P40527|ATC7_YEAST",
              "sp|P40530|PDK1_YEAST", "sp|P40989|FKS2_YEAST",
              "sp|P49955|SF3B1_YEAST", "sp|P51401|RL9B_YEAST",
              "sp|P53072|TAN1_YEAST", "sp|Q03964|YD17A_YEAST",
              "sp|Q04670|YM14B_YEAST;sp|Q12088|YL11B_YEAST;sp|Q03619|YE12B_YEAST",
              "sp|Q08649|ESA1_YEAST", "sp|Q12112|YN11B_YEAST",
              "sp|Q12479|IRC11_YEAST", "sp|Q3E7B7|YD85C_YEAST")

cptac <- cptac[!fData(cptac)$Proteins %in% ptm_only, ]

processingData(cptac)

exprs(cptac)[1:10, ]
anyNA(cptac)

limma::plotDensities(
  log2(exprs(cptac) + 1),
  legend = FALSE)
log2(0 + 1)

exprs(cptac)[1:5, 1:3]
(exprs(cptac) == 0)[1:5, 1:3]
exprs(cptac)[exprs(cptac) == 0] <- 
  NA
anyNA(cptac)

table(is.na(cptac))
sum(is.na(cptac))/prod(dim(cptac))


naplot(cptac, 
       col = c("black", "white"))

cptac$nNA <- colSums(is.na(cptac))
pData(cptac)

fData(cptac)$nNA <- rowSums(is.na(cptac))
fvarLabels(cptac)
table(fData(cptac)$nNA)

fData(cptac)$nNAa <- 
  rowSums(is.na(exprs(cptac)[, cptac$condition == "A"]))
fData(cptac)$nNAb <- 
  rowSums(is.na(exprs(cptac)[, cptac$condition == "B"]))

plotNA(cptac)

## filtering
filterNA(cptac)
filterNA(cptac, pNA = .5)
cptac[!fData(cptac)$nNA == 6, ]

## imputation - ?impute
## stats!

cptac <- cptac[fData(cptac)$nNA <= 4, ]
processingData(cptac)

boxplot(exprs(cptac))

cptac <- log(cptac, base = 2)
boxplot(exprs(cptac))
processingData(cptac)

library(limma)
plotDensities(exprs(cptac), 
              legend = FALSE)
?normalise
cptac <- 
  normalise(cptac, 
            method = "quantiles")
## normalize(cptac, method = "vsn")
plotDensities(exprs(cptac), 
              legend = FALSE)

cptac

plotMDS(exprs(cptac), 
  col = as.numeric(factor(cptac$condition)))

pca <- 
  prcomp(t(exprs(impute(cptac, 
                        method = "zero"))),
       scale = TRUE,
       center = TRUE)

summary(pca)
library(factoextra)
fviz_pca_ind(pca, 
        habillage = as.factor(cptac$condition))
dim(cptac)


fvarLabels(cptac)

cptac_prot <- 
  combineFeatures(cptac, 
                fcol = "Proteins",
                method = "median",
                na.rm = TRUE)
cptac_prot

naplot(cptac_prot,
       col = c("black",
               "white"))

sum(c(1, 2, 3, NA), na.rm = TRUE)
median(c(1, 2, 3, NA), na.rm = TRUE)
mean(c(1, 2, 3, NA), na.rm = TRUE)

?combineFeatures


plotMDS(exprs(cptac), 
        col = as.numeric(factor(cptac$condition)))


plotMDS(exprs(cptac_prot), 
        col = as.numeric(factor(cptac$condition)))

## combine data using 
## robust summarisation (aggregation)

cptac_robust <- 
  combineFeatures(cptac, 
                  fcol = "Proteins",
                  method = "robust",
                  na.rm = TRUE)
cptac_robust
plotMDS(exprs(cptac_robust), 
        col = as.numeric(factor(cptac$condition)))

pca <- 
  prcomp(t(exprs(filterNA(cptac_robust))),
         scale = TRUE,
         center = TRUE)

fviz_pca_ind(pca, 
             habillage = as.factor(cptac$condition))
plotNA(cptac_robust)


## imputation - see ?impute and 
## notes https://lgatto.github.io/2020-02-17-RProt-Berlin/sec-quant.html#missing-values)

data(naset)
fvarLabels(naset)
table(fData(naset)$randna)

## statisitical analysis
library(limma)

design <- 
  model.matrix(~ cptac_robust$condition)
fit <- lmFit(exprs(cptac_robust), design)
fit <- eBayes(fit)
class(fit)
res <- topTable(fit, coef = "cptac_robust$conditionB", 
                number = Inf)

class(res)
dim(res)
head(res)

hist(res$P.Value, breaks = 200)
sum(res$P.Value < 0.05, na.rm = TRUE)
sum(res$adj.P.Val < 0.05, na.rm = TRUE)


head(rownames(res))
head(featureNames(cptac_robust))

library(tidyverse)
fData(cptac_robust) <-
  full_join(rownames_to_column(fData(cptac_robust)),
            rownames_to_column(res)) %>%
  column_to_rownames()

fData(cptac_robust)$ups <- 
  grepl("UPS", featureNames(cptac_robust))
fvarLabels(cptac_robust)

fData(cptac_robust) %>%
  ggplot(aes(x = logFC, 
             y = -log10(adj.P.Val),
             colour = ups)) +
  geom_point()


ms2df(cptac_robust) %>%
  filter(is.na(P.Value)) %>% 
  select(Proteins, 
         starts_with("X"))



dim(cptac)
dim(cptac_robust)






