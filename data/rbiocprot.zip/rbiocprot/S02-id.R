library(msdata)
idf <- msdata::ident(full.names = TRUE)
idf

library(MSnbase)

## read the idf file using 
## MSnbase::readMzIdData()

iddf <- readMzIdData(idf)

## what type of object to you get?
class(iddf)
## how many entries?
nrow(iddf)
## how many from real db?
## how many from decoy?
names(iddf)
View(iddf)

table(iddf$isDecoy)
table(iddf$rank)

iddf2 <- filterIdentificationDataFrame(iddf)
table(iddf2$isDecoy)
table(iddf2$rank)

## plot the distribution 
## of MS.GF.RawScore for the 
## decoy and real hits

library(ggplot2)
ggplot(iddf, 
       aes(x = MS.GF.RawScore,
           colour = isDecoy)) + 
  geom_density()

ggplot(iddf, 
       aes(x = MS.GF.QValue,
           colour = isDecoy)) + 
  geom_density()


## combine raw and id data

rwf <- dir(system.file(package = "MSnbase", 
                dir = "extdata"),
           full.names = TRUE, 
           pattern = "mzXML$")
basename(rwf)

idf <- dir(system.file(package = "MSnbase", 
                       dir = "extdata"),
           full.names = TRUE, 
           pattern = "dummyiTRAQ.mzid")
basename(idf)

rw <- readMSData(rwf)
rw
fData(rw)

rw <- addIdentificationData(rw, idf)
fData(rw)

rw[!is.na(fData(rw)$sequence)]


?addIdentificationData


data("itraqdata")
itraqdata2 <- pickPeaks(itraqdata)

fData(itraqdata2)
class(itraqdata2)
s <- as.character(fData(itraqdata2)$PeptideSequence[14])
s

plot(itraqdata2[[14]], full = TRUE)
plot(itraqdata2[[14]], s)


pepseqs <- as.character(fData(itraqdata2)$PeptideSequence)
table(pepseqs)

which(pepseqs == "IMIDLDGTENK")

pepseqs[c(25, 28)]
plot(itraqdata2[c(25, 28)], full = TRUE)
rtime(itraqdata2)[c(25, 28)]

plot(itraqdata2[[25]], 
     itraqdata2[[28]], 
     sequences = pepseqs[c(25, 28)])

calculateFragments(s)

## use compareSpectra() 
compareSpectra(itraqdata2[[25]], 
               itraqdata2[[28]],
               fun = "common")
     
compareSpectra(itraqdata2[[25]], 
               itraqdata2[[28]],
               fun = "cor")

compareSpectra(itraqdata2[[25]], 
               itraqdata2[[28]],
               fun = "dotproduct")

all_comp <- compareSpectra(itraqdata2, 
                           fun = "dotproduct")
class(all_comp)
dim(all_comp)
all_comp[1:5, 1:5]

## MSnID
library(MSnID)
## BiocManager::install("MSnID")

mzids <- system.file("extdata",  
                     "c_elegans.mzid.gz", 
            package = "MSnID")
mzids

## load the id results as a dataframe
## plot the score decoy and real
## distributions for these id results

iddf <- readMzIdData(mzids)
ggplot(iddf, 
       aes(x = MS.GF.RawScore,
           colour = isDecoy)) + 
  geom_density()


msnid <- MSnID(".")
msnid <- read_mzIDs(msnid, mzids)
msnid
names(msnid)

msnid <- assess_termini(msnid, 
            validCleavagePattern = "[KR]\\.[^P]")
msnid <- assess_missed_cleavages(msnid, 
            missedCleavagePattern = "[KR](?=[^P$])")

msnid <- apply_filter(msnid, "numIrregCleavages == 0")
msnid
msnid <- apply_filter(msnid, "numMissCleavages <= 2")
msnid
names(msnid)

msnid

summary(mass_measurement_error(msnid))

msnid <- apply_filter(msnid, 
        "abs(mass_measurement_error(msnid)) < 20")

msnid$msmsScore <- -log10(msnid$`MS-GF:SpecEValue`)

msnid$absParentMassErrorPPM <- 
  abs(mass_measurement_error(msnid))


library(magrittr)
library(ggplot2)
data.frame(msnid$msmsScore, msnid$isDecoy) %>%
  ggplot(aes(x = msnid.msmsScore, 
             colour = msnid.isDecoy)) +
    geom_density()

filtObj <- MSnIDFilter(msnid)
filtObj$absParentMassErrorPPM <- 
  list(comparison = "<", threshold = 10)
filtObj$msmsScore <- 
  list(comparison = ">", threshold = 10)
filtObj

evaluate_filter(msnid, filtObj)


filtObj_grid <- 
  optimize_filter(filtObj,
                msnid, 
                fdr.max = 0.01,
                level = "peptide",
                method = "Grid",
                n.iter = 500)
filtObj_grid

msnid <- apply_filter(msnid, filtObj_grid)
msnid

data.frame(msnid$msmsScore, msnid$isDecoy) %>%
  ggplot(aes(x = msnid.msmsScore, 
             colour = msnid.isDecoy)) +
  geom_density()


msnid <- apply_filter(msnid, "isDecoy == FALSE")
msnid <- apply_filter(msnid, 
                      "!grepl('Contaminant', accession)")

msnid

final_psms <- psms(msnid)
dim(final_psms)
class(final_psms)
table(final_psms$pepSeq)

msnset0 <- as(msnid, "MSnSet")
library(MSnbase)
head(exprs(msnset0))


